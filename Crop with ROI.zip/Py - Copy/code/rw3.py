import numpy as np
import cv2

img = cv2.imread(r'D:\BC\C4.png')
img = img[:-5,:-5]
gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
gray = 255*(gray < 128).astype(np.uint8)
gray = cv2.morphologyEx(gray, cv2.MORPH_OPEN, np.ones((2, 2), dtype=np.uint8))

coords = cv2.findNonZero(gray)
x, y, w, h = cv2.boundingRect(coords)
rect = img[y:y+h, x:x+w]
#cv2.imshow("Cropped", rect)

cv2.waitKey(0)
cv2.destroyAllWindows()
cv2.imwrite("Output.png", rect)

