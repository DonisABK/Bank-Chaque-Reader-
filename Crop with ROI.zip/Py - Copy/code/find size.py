# Importing Image class from PIL module
from PIL import Image

# Opens a image in RGB mode
im1 = Image.open(r"D:\BC\BOI.jpg")
im2 = Image.open(r"D:\BC\BB.jpg")
im3 = Image.open(r"D:\BC\CAB .jpg")

# Size of the image in pixels (size of original image)
# (This is not mandatory)
width, height = im1.size
width, height = im2.size
width, height = im3.size

print(im2.size,"  ", im1.size," ", im3.size)