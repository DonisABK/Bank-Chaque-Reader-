# Importing Image class from PIL module
from PIL import Image

# Opens a image in RGB mode
im = Image.open(r"D:\BC\Checks\TCCUB.jpg")

# Size of the image in pixels (size of original image)
# (This is not mandatory)
width, height = im.size

print(im.size)
# Setting the points for cropped image
left = 1
top = 1
right = 4819
bottom = 2200

#im1 = im.crop((left, top, right, bottom))
#im1.show()

bname_left = 1
bname_right =3000
bname_top = 1
bname_bottom = 500

im_bname = im.crop((bname_left, bname_top, bname_right, bname_bottom))

im_bname.show()

