from PIL import Image, ImageChops

def trim(im):
    bg = Image.new(im.mode, im.size, im.getpixel((4800,6800)))
    #bg = Image.new(im.mode, im.size, (255, 255, 255))
    print(bg)
    print(type(bg))
    diff = ImageChops.difference(im, bg)
    diff = ImageChops.add(diff, diff, 10.0, -100)
    bbox = diff.getbbox()
    if bbox:
        return im.crop(bbox)
    else:
        # Failed to find the borders, convert to "RGB"
        return trim(im.convert('RGB'))

im = Image.open(r"D:\BC\Checks\TCCUB.jpg")
im = trim(im)
im.show()