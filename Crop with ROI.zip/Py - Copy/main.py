# Importing Image class from PIL module
import os
import shutil

from PIL import Image
import csv

# Opens a image in RGB mode
Bcode = 'TKDCB'
im = Image.open(r"D:\BC\Checks\%s.jpg" % Bcode)

#creating folder in bank code

parent_dir = "D:/BC/Checks/Croped/"
directory = parent_dir + Bcode

if os.path.exists(directory):
    shutil.rmtree(directory)
os.makedirs(directory)


#cropping bank name
bname_left = 1
bname_right =2700
bname_top = 1
bname_bottom = 550

im_bname = im.crop((bname_left, bname_top, bname_right, bname_bottom))
im_bname.show()

with open('D:\BC\ROI.csv') as csv_file:
    csv_reader = csv.reader(csv_file)
    rows = list(csv_reader)

    for i in range(3, 16):
        if rows[i][0] == Bcode:
            print("rows i", rows[i])

            width, height = im.size
            date_img = im.crop((int(rows[i][7]), 1, width, int(rows[i][8])))
            #date_img.show()
            date_img.save(directory+"/"+Bcode+"_date.jpg")
            body_img = im.crop((1, int(rows[i][9]), width, int(rows[i][10])))
            #body_img.show()
            date_img.save(directory+"/"+Bcode+"_date.jpg")
            ocr_img = im.crop((1, int(rows[i][6]), width, 2300))
            #ocr_img.show()


# Size of the image in pixels (size of original image)
# (This is not mandatory)
#width, height = im.size

#im1 = im.crop((left, top, right, bottom))
#im1.show()


#print(type(im_bname))
#im_bname.save("D:\BC\Checks\Croped\TCCUB.jpg")
#im_bname.show()

def crop(left, right, top, bottom):
    croped = im.crop(left, top, right, bottom)
    return croped

