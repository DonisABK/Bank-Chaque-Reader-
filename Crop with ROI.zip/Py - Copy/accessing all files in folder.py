import os

import cv2
import numpy as np
import glob

parent_dir = "D:/BC/Checks/Croped"
directory = "test"
mode = 0o666
path = os.path.join(parent_dir, directory)
os.makedirs(path, mode)

for img_path in glob.glob('D:\BC\Checks\*.jpg'):
    try:
        img = cv2.imread(img_path)
        print(img_path)

    except:
        print('fail')